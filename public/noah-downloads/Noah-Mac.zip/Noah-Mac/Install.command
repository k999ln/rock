#!/bin/zsh
set -eu
cd -- "$(dirname -- "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null; then
  echo 'Node.js 24以上が必要です。https://nodejs.org/en/download からインストールして再実行してください。'
  read '?Enterで閉じる'
  exit 1
fi
node install.mjs
read '?Enterで閉じる'
