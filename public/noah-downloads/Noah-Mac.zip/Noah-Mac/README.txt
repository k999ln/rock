Noah Mac preview
Apple Silicon / macOS. Node.js 24+, Colima, Docker CLI, Ollama and Git are required.
Install.command installs only into your account. It does not log in or start jobs.
Then use noah pair and noah start. Control jobs from https://avoado.si/noah/launch.
Initial login and runtime installation require your own action.
This preview has not yet passed acceptance on a second Mac.
