# Sky MCP Connector

Skyと複数のMCP serverの間で動く、PC内の共通Connectorです。`registry.json`へ接続定義を追加すると、Sky側のコードを変えずに同じ「接続 → initialize → tools/list → Connection Passport → 承認付き実行」を使えます。

## 起動

Node.js 22.13以上が必要です。macOSは配布パック内の`Sky MCP接続.command`を開きます。開発環境ではrepository rootから次を実行します。

```sh
npm run mcp:connector
```

Connectorは`127.0.0.1:38479`だけで待ち受けます。Skyの許可済みOrigin以外は拒否し、ブラウザsessionと接続tokenを結びます。

## MCPを追加

Sky Tool SDK 0.1.1以降で起動したToolは、このPCの接続一覧へ自動で現れます。SDKのプロセスを起動したままSkyで「MCP → 導入・接続」を開き、「接続」を押してください。PC内の登録定義には接続用の一時キーを含むため、SDKが所有者専用の権限で保存します。終了時は定義を削除します。手動のregistry編集は不要です。

stdio MCPは、`registry.json`へ実行ファイルと引数を別々に指定します。shell文字列は実行せず、`shell: false`で起動します。MCPへ渡す環境変数も名前だけをallowlistに追加し、値はPC側の環境から読みます。

```json
{
  "id": "my-automation",
  "name": "自分の自動化",
  "description": "何を行うMCPか",
  "transport": "stdio",
  "command": "node",
  "args": ["my-automation/server.mjs"],
  "cwd": "..",
  "env": ["MY_AUTOMATION_TOKEN"],
  "required": false
}
```

遠隔MCPは`transport: "streamable_http"`とHTTPS URLを指定します。redirect、URL内の認証情報、private/loopback/link-local IPへの接続を拒否します。Bearer tokenが必要なら値ではなく`authEnv`へ環境変数名を指定します。OAuth browser flowはまだ未接続で、401/403は`needs_authorization`として停止します。

## 安全境界

- PC内の接続定義はsymlinkをたどらず一度だけ開き、同じfile handleで種類・private権限・sizeを確認して読みます。読取中に増えた場合も4 KiBを超えれば拒否し、不正・非通常fileを接続候補にしません。既定の所有者専用directoryとその親は信頼する境界です。
- POSIXでは接続定義の所有者が実効UIDと一致する必要があります。必要な安全なopen flagがない環境ではlocal自動検出を拒否します。
- 接続時にprotocol version、server identity、capabilities、tool schemaを取得し、SHA-256 digest付きConnection Passportを作ります。
- tool annotationsは第三者入力として扱い、全toolを既定で承認必須にします。
- 実行前の`prepare`でserver・tool・引数・tool digestに結び付いた5分有効の一回券を発行します。
- `execute`は同じ内容と明示確認がある時だけ通します。券の再利用や承認後の引数変更は拒否します。
- `tools/call`は自動再送しません。送信後timeoutは`outcome_unknown`として、人またはprovider固有status APIで照合します。
- 旧`/mcp`は正確な同梱MR接続定義と基本4機能・lifecycleだけの互換例外です。一回券は要求しませんが、Originとsession認証を維持します。同名の別接続定義や追加操作は転送前に403 `legacy_mcp_not_supported`で拒否します。追加Toolはserver IDの接続→prepare→本人確認→executeを使ってください。
- UIから任意commandを登録するAPIはありません。配布・審査済みregistryをPC所有者が導入します。

詳しい共通契約は[`../../docs/sky-mcp-connector.md`](../../docs/sky-mcp-connector.md)を参照してください。
