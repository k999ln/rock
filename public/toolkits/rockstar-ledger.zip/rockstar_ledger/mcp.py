from __future__ import annotations

import json
import sys
from typing import Any

from .db import export_json, list_subscriptions, summary, upsert_subscription
from .recurring import detect_recurring, import_csv_text


TOOLS = [
    {
        "name": "ledger_summary",
        "description": "Return the offline subscription dashboard, monthly totals, and urgent alerts.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "list_subscriptions",
        "description": "List subscriptions, optionally filtered by status.",
        "inputSchema": {"type": "object", "properties": {"status": {"type": "string"}}, "additionalProperties": False},
    },
    {
        "name": "upsert_subscription",
        "description": "Create or update a local subscription record by name.",
        "inputSchema": {
            "type": "object",
            "required": ["name"],
            "properties": {
                "name": {"type": "string"},
                "category": {"type": "string"},
                "status": {"type": "string", "enum": ["active", "action_required", "paused", "cancelled", "expired", "free", "trial", "usage_based"]},
                "amount": {"type": "number"},
                "currency": {"type": "string"},
                "billing_cycle": {"type": "string", "enum": ["weekly", "monthly", "quarterly", "annual", "one_time", "usage", "free"]},
                "renewal_date": {"type": ["string", "null"]},
                "payment_method": {"type": "string"},
                "source": {"type": "string"},
                "confidence": {"type": "number"},
                "notes": {"type": "string"},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "import_transactions_csv",
        "description": "Import bank/card CSV text locally and return recurring-charge candidates. Data is never uploaded.",
        "inputSchema": {
            "type": "object",
            "required": ["csv_text"],
            "properties": {"csv_text": {"type": "string"}, "source": {"type": "string"}, "default_currency": {"type": "string"}},
            "additionalProperties": False,
        },
    },
    {
        "name": "detect_recurring_charges",
        "description": "Analyze imported transactions for weekly, monthly, and annual recurring charges.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
]


def tool_call(name: str, args: dict[str, Any]) -> Any:
    if name == "ledger_summary":
        return summary()
    if name == "list_subscriptions":
        return list_subscriptions(args.get("status"))
    if name == "upsert_subscription":
        return upsert_subscription(args)
    if name == "import_transactions_csv":
        return import_csv_text(args["csv_text"], args.get("source", "mcp"), args.get("default_currency", "USD"))
    if name == "detect_recurring_charges":
        return detect_recurring()
    raise ValueError(f"unknown tool: {name}")


def response(request_id: Any, result: Any = None, error: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": request_id}
    payload["error" if error else "result"] = error or result
    return payload


def handle(message: dict[str, Any]) -> dict[str, Any] | None:
    method = message.get("method")
    request_id = message.get("id")
    if request_id is None:
        return None
    if method == "initialize":
        return response(request_id, {"protocolVersion": "2025-06-18", "capabilities": {"tools": {}, "resources": {}}, "serverInfo": {"name": "rockstar-ledger", "version": "0.1.0"}})
    if method == "ping":
        return response(request_id, {})
    if method == "tools/list":
        return response(request_id, {"tools": TOOLS})
    if method == "tools/call":
        params = message.get("params", {})
        try:
            value = tool_call(params.get("name", ""), params.get("arguments", {}))
            return response(request_id, {"content": [{"type": "text", "text": json.dumps(value, ensure_ascii=False, indent=2)}], "isError": False})
        except Exception as exc:
            return response(request_id, {"content": [{"type": "text", "text": str(exc)}], "isError": True})
    if method == "resources/list":
        return response(request_id, {"resources": [{"uri": "subscription://dashboard", "name": "Subscription dashboard", "mimeType": "application/json"}]})
    if method == "resources/read":
        uri = message.get("params", {}).get("uri")
        if uri != "subscription://dashboard":
            return response(request_id, error={"code": -32602, "message": "Unknown resource"})
        return response(request_id, {"contents": [{"uri": uri, "mimeType": "application/json", "text": json.dumps(export_json(), ensure_ascii=False, indent=2)}]})
    return response(request_id, error={"code": -32601, "message": f"Method not found: {method}"})


def main() -> None:
    for line in sys.stdin:
        try:
            message = json.loads(line)
            result = handle(message)
            if result is not None:
                print(json.dumps(result, ensure_ascii=False), flush=True)
        except Exception as exc:
            print(json.dumps(response(None, error={"code": -32700, "message": str(exc)}), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()

