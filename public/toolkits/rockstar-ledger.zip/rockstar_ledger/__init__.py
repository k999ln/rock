"""Rockstar Ledger: local-first subscription intelligence."""

__version__ = "0.2.0"
