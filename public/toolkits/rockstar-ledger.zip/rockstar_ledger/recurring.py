from __future__ import annotations

import csv
import hashlib
import io
import re
import statistics
from collections import defaultdict
from datetime import date
from typing import Any

from .db import DEFAULT_COVERAGE_SOURCES, connect, init_db, record_source_import, utc_now


DATE_KEYS = ("date", "transaction_date", "posted_date", "日付", "利用日")
MERCHANT_KEYS = ("merchant", "description", "name", "摘要", "利用先", "加盟店")
AMOUNT_KEYS = ("amount", "debit", "金額", "利用金額")
CURRENCY_KEYS = ("currency", "通貨")
ID_KEYS = ("id", "transaction_id", "reference", "取引id")


def normalize_merchant(value: str) -> str:
    value = value.upper().strip()
    value = re.sub(r"^(SQ\s*\*|PAYPAL\s*\*|APPLE\.COM/BILL|GOOGLE\s*\*)", "", value)
    value = re.sub(r"[^A-Z0-9ぁ-んァ-ン一-龥]+", " ", value)
    return " ".join(value.split())


def _pick(row: dict[str, str], keys: tuple[str, ...]) -> str:
    lowered = {k.lower().strip(): (v or "").strip() for k, v in row.items() if k}
    for key in keys:
        if key.lower() in lowered and lowered[key.lower()] != "":
            return lowered[key.lower()]
    return ""


def _parse_amount(value: str) -> float:
    cleaned = value.replace(",", "").replace("¥", "").replace("$", "").strip()
    if cleaned.startswith("(") and cleaned.endswith(")"):
        cleaned = f"-{cleaned[1:-1]}"
    return abs(float(cleaned))


def _parse_date(value: str) -> str:
    value = value.strip()
    for separator in ("/", "."):
        value = value.replace(separator, "-")
    return date.fromisoformat(value).isoformat()


def import_csv_text(
    text: str,
    source: str = "csv",
    default_currency: str = "USD",
    source_kind: str = "credit_card",
) -> dict[str, Any]:
    if source_kind not in {item[0] for item in DEFAULT_COVERAGE_SOURCES}:
        raise ValueError(f"invalid coverage source: {source_kind}")
    init_db()
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    inserted = 0
    skipped = 0
    parsed_dates: list[str] = []
    with connect() as conn:
        for row in reader:
            try:
                occurred_on = _parse_date(_pick(row, DATE_KEYS))
                merchant = _pick(row, MERCHANT_KEYS)
                amount = _parse_amount(_pick(row, AMOUNT_KEYS))
                if not merchant:
                    raise ValueError("missing merchant")
                currency = (_pick(row, CURRENCY_KEYS) or default_currency).upper()
                external_id = _pick(row, ID_KEYS)
                if not external_id:
                    fingerprint = f"{occurred_on}|{merchant}|{amount}|{currency}"
                    external_id = hashlib.sha256(fingerprint.encode()).hexdigest()[:24]
                cursor = conn.execute(
                    """
                    INSERT OR IGNORE INTO transactions (
                        occurred_on, merchant, normalized_merchant, amount, currency,
                        source, external_id, memo, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (occurred_on, merchant, normalize_merchant(merchant), amount, currency, source, external_id, "", utc_now()),
                )
                inserted += cursor.rowcount
                skipped += int(cursor.rowcount == 0)
                parsed_dates.append(occurred_on)
            except (TypeError, ValueError):
                skipped += 1
    if parsed_dates:
        record_source_import(source_kind, inserted, min(parsed_dates), max(parsed_dates))
    return {
        "inserted": inserted,
        "skipped": skipped,
        "source_kind": source_kind,
        "history_start": min(parsed_dates) if parsed_dates else None,
        "history_end": max(parsed_dates) if parsed_dates else None,
        "recurring_candidates": detect_recurring(),
    }


def detect_recurring() -> list[dict[str, Any]]:
    init_db()
    with connect() as conn:
        rows = conn.execute(
            "SELECT occurred_on, merchant, normalized_merchant, amount, currency FROM transactions ORDER BY occurred_on"
        ).fetchall()
    groups: dict[tuple[str, str], list[Any]] = defaultdict(list)
    for row in rows:
        groups[(row["normalized_merchant"], row["currency"])].append(row)
    candidates = []
    for (merchant, currency), items in groups.items():
        if len(items) < 2:
            continue
        dates = [date.fromisoformat(item["occurred_on"]) for item in items]
        gaps = [(b - a).days for a, b in zip(dates, dates[1:])]
        amounts = [float(item["amount"]) for item in items]
        median_gap = statistics.median(gaps)
        mean_amount = statistics.mean(amounts)
        spread = (max(amounts) - min(amounts)) / mean_amount if mean_amount else 1
        if 25 <= median_gap <= 35:
            cycle = "monthly"
        elif 350 <= median_gap <= 380:
            cycle = "annual"
        elif 6 <= median_gap <= 8:
            cycle = "weekly"
        else:
            continue
        confidence = max(0.5, min(0.99, 0.95 - spread))
        candidates.append(
            {
                "merchant": merchant,
                "display_name": items[-1]["merchant"],
                "currency": currency,
                "amount": round(statistics.median(amounts), 2),
                "billing_cycle": cycle,
                "occurrences": len(items),
                "last_seen": dates[-1].isoformat(),
                "confidence": round(confidence, 2),
            }
        )
    return sorted(candidates, key=lambda item: (-item["confidence"], item["display_name"]))
