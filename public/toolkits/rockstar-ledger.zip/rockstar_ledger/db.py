from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterator


ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DB = ROOT / "data" / "ledger.sqlite3"
VALID_STATUSES = {
    "active",
    "action_required",
    "paused",
    "cancelled",
    "expired",
    "free",
    "trial",
    "usage_based",
}
VALID_CYCLES = {"weekly", "monthly", "quarterly", "annual", "one_time", "usage", "free"}
VALID_COVERAGE_STATUSES = {"unconfirmed", "pending", "imported", "verified", "not_used"}
DEFAULT_COVERAGE_SOURCES = (
    ("apple", "Appleのサブスクリプション"),
    ("google_play", "Google Play"),
    ("credit_card", "クレジットカード"),
    ("bank", "銀行口座"),
    ("paypal", "PayPal"),
    ("email", "請求メール・領収書"),
)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def db_path() -> Path:
    configured = os.environ.get("ROCKSTAR_LEDGER_DB")
    return Path(configured).expanduser().resolve() if configured else DEFAULT_DB


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                category TEXT NOT NULL DEFAULT 'Other',
                status TEXT NOT NULL DEFAULT 'active',
                amount REAL NOT NULL DEFAULT 0,
                currency TEXT NOT NULL DEFAULT 'USD',
                billing_cycle TEXT NOT NULL DEFAULT 'monthly',
                renewal_date TEXT,
                payment_method TEXT,
                source TEXT NOT NULL DEFAULT 'manual',
                confidence REAL NOT NULL DEFAULT 1,
                notes TEXT NOT NULL DEFAULT '',
                last_verified_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                occurred_on TEXT NOT NULL,
                merchant TEXT NOT NULL,
                normalized_merchant TEXT NOT NULL,
                amount REAL NOT NULL,
                currency TEXT NOT NULL DEFAULT 'USD',
                source TEXT NOT NULL DEFAULT 'csv',
                external_id TEXT,
                memo TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                UNIQUE(source, external_id)
            );

            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subscription_id INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
                kind TEXT NOT NULL,
                observed_at TEXT NOT NULL,
                summary TEXT NOT NULL,
                source_ref TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS coverage_sources (
                kind TEXT PRIMARY KEY,
                label TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'unconfirmed',
                history_start TEXT,
                history_end TEXT,
                item_count INTEGER NOT NULL DEFAULT 0,
                notes TEXT NOT NULL DEFAULT '',
                last_checked_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
            CREATE INDEX IF NOT EXISTS idx_transactions_merchant ON transactions(normalized_merchant);
            CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(occurred_on);
            """
        )
        now = utc_now()
        conn.executemany(
            """
            INSERT OR IGNORE INTO coverage_sources (
                kind, label, status, created_at, updated_at
            ) VALUES (?, ?, 'unconfirmed', ?, ?)
            """,
            [(kind, label, now, now) for kind, label in DEFAULT_COVERAGE_SOURCES],
        )


def _validate_subscription(item: dict[str, Any]) -> dict[str, Any]:
    name = str(item.get("name", "")).strip()
    if not name:
        raise ValueError("name is required")
    status = str(item.get("status", "active"))
    if status not in VALID_STATUSES:
        raise ValueError(f"invalid status: {status}")
    cycle = str(item.get("billing_cycle", "monthly"))
    if cycle not in VALID_CYCLES:
        raise ValueError(f"invalid billing_cycle: {cycle}")
    amount = float(item.get("amount", 0))
    if amount < 0:
        raise ValueError("amount must be zero or positive")
    renewal = item.get("renewal_date") or None
    if renewal:
        date.fromisoformat(str(renewal))
    return {
        "name": name,
        "category": str(item.get("category") or "Other"),
        "status": status,
        "amount": amount,
        "currency": str(item.get("currency") or "USD").upper(),
        "billing_cycle": cycle,
        "renewal_date": renewal,
        "payment_method": str(item.get("payment_method") or ""),
        "source": str(item.get("source") or "manual"),
        "confidence": min(1.0, max(0.0, float(item.get("confidence", 1)))),
        "notes": str(item.get("notes") or ""),
        "last_verified_at": str(item.get("last_verified_at") or utc_now()),
    }


def upsert_subscription(item: dict[str, Any]) -> dict[str, Any]:
    init_db()
    clean = _validate_subscription(item)
    now = utc_now()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO subscriptions (
                name, category, status, amount, currency, billing_cycle,
                renewal_date, payment_method, source, confidence, notes,
                last_verified_at, created_at, updated_at
            ) VALUES (
                :name, :category, :status, :amount, :currency, :billing_cycle,
                :renewal_date, :payment_method, :source, :confidence, :notes,
                :last_verified_at, :created_at, :updated_at
            )
            ON CONFLICT(name) DO UPDATE SET
                category=excluded.category,
                status=excluded.status,
                amount=excluded.amount,
                currency=excluded.currency,
                billing_cycle=excluded.billing_cycle,
                renewal_date=excluded.renewal_date,
                payment_method=excluded.payment_method,
                source=excluded.source,
                confidence=excluded.confidence,
                notes=excluded.notes,
                last_verified_at=excluded.last_verified_at,
                updated_at=excluded.updated_at
            """,
            clean | {"created_at": now, "updated_at": now},
        )
        row = conn.execute("SELECT * FROM subscriptions WHERE name = ? COLLATE NOCASE", (clean["name"],)).fetchone()
    return dict(row)


def list_subscriptions(status: str | None = None) -> list[dict[str, Any]]:
    init_db()
    query = "SELECT * FROM subscriptions"
    params: tuple[Any, ...] = ()
    if status:
        query += " WHERE status = ?"
        params = (status,)
    query += " ORDER BY CASE status WHEN 'action_required' THEN 0 WHEN 'active' THEN 1 ELSE 2 END, name"
    with connect() as conn:
        return [dict(row) for row in conn.execute(query, params).fetchall()]


def add_evidence(subscription_id: int, kind: str, summary: str, observed_at: str | None = None, source_ref: str = "") -> None:
    init_db()
    with connect() as conn:
        conn.execute(
            "INSERT INTO evidence (subscription_id, kind, observed_at, summary, source_ref, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (subscription_id, kind, observed_at or utc_now(), summary, source_ref, utc_now()),
        )


def list_evidence(subscription_id: int) -> list[dict[str, Any]]:
    init_db()
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM evidence WHERE subscription_id = ? ORDER BY observed_at DESC", (subscription_id,)
        ).fetchall()
    return [dict(row) for row in rows]


def _optional_date(value: Any, field: str) -> str | None:
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(str(value)).isoformat()
    except ValueError as exc:
        raise ValueError(f"{field} must be an ISO date") from exc


def upsert_coverage_source(item: dict[str, Any]) -> dict[str, Any]:
    init_db()
    kind = str(item.get("kind", "")).strip()
    if kind not in {source[0] for source in DEFAULT_COVERAGE_SOURCES}:
        raise ValueError(f"invalid coverage source: {kind}")
    with connect() as conn:
        current = conn.execute("SELECT * FROM coverage_sources WHERE kind = ?", (kind,)).fetchone()
        if current is None:
            raise ValueError(f"unknown coverage source: {kind}")
        status = str(item.get("status", current["status"]))
        if status not in VALID_COVERAGE_STATUSES:
            raise ValueError(f"invalid coverage status: {status}")
        history_start = _optional_date(item.get("history_start", current["history_start"]), "history_start")
        history_end = _optional_date(item.get("history_end", current["history_end"]), "history_end")
        if history_start and history_end and history_start > history_end:
            raise ValueError("history_start must not be after history_end")
        checked = item.get("last_checked_at")
        if checked is None and status in {"imported", "verified", "not_used"}:
            checked = utc_now()
        now = utc_now()
        conn.execute(
            """
            UPDATE coverage_sources SET
                status = ?, history_start = ?, history_end = ?,
                item_count = ?, notes = ?, last_checked_at = ?, updated_at = ?
            WHERE kind = ?
            """,
            (
                status,
                history_start,
                history_end,
                max(0, int(item.get("item_count", current["item_count"]))),
                str(item.get("notes", current["notes"])),
                checked if checked is not None else current["last_checked_at"],
                now,
                kind,
            ),
        )
        row = conn.execute("SELECT * FROM coverage_sources WHERE kind = ?", (kind,)).fetchone()
    return dict(row)


def list_coverage_sources() -> list[dict[str, Any]]:
    init_db()
    order = {kind: index for index, (kind, _) in enumerate(DEFAULT_COVERAGE_SOURCES)}
    with connect() as conn:
        rows = [dict(row) for row in conn.execute("SELECT * FROM coverage_sources").fetchall()]
    return sorted(rows, key=lambda row: order.get(row["kind"], len(order)))


def record_source_import(kind: str, count: int, history_start: str | None, history_end: str | None) -> None:
    if kind not in {source[0] for source in DEFAULT_COVERAGE_SOURCES}:
        return
    current = next(source for source in list_coverage_sources() if source["kind"] == kind)
    starts = [value for value in (current["history_start"], history_start) if value]
    ends = [value for value in (current["history_end"], history_end) if value]
    upsert_coverage_source(
        {
            "kind": kind,
            "status": "imported" if current["status"] not in {"verified", "not_used"} else current["status"],
            "history_start": min(starts) if starts else None,
            "history_end": max(ends) if ends else None,
            "item_count": current["item_count"] + count,
            "last_checked_at": utc_now(),
        }
    )


def coverage_report() -> dict[str, Any]:
    sources = list_coverage_sources()
    resolved = [source for source in sources if source["status"] in {"verified", "not_used"}]
    imported = [source for source in sources if source["status"] == "imported"]
    unresolved = [source for source in sources if source["status"] not in {"verified", "not_used"}]
    subscriptions = list_subscriptions()
    recurring_statuses = {"active", "action_required", "trial", "paused"}
    recurring_cycles = {"weekly", "monthly", "quarterly", "annual"}
    future_items = [
        subscription
        for subscription in subscriptions
        if subscription["status"] in recurring_statuses and subscription["billing_cycle"] in recurring_cycles
    ]
    renewal_known = sum(bool(subscription["renewal_date"]) for subscription in future_items)
    with connect() as conn:
        transaction_count = int(conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0])
        evidence_count = int(conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0])
    discovery_complete = not unresolved
    future_ready = renewal_known == len(future_items)
    return {
        "complete": discovery_complete and future_ready,
        "discovery_complete": discovery_complete,
        "future_ready": future_ready,
        "sources": sources,
        "source_counts": {
            "total": len(sources),
            "resolved": len(resolved),
            "imported": len(imported),
            "unresolved": len(unresolved),
        },
        "unresolved_sources": [source["label"] for source in unresolved],
        "transactions_imported": transaction_count,
        "evidence_records": evidence_count,
        "historical_subscriptions": sum(
            subscription["status"] in {"cancelled", "expired"} for subscription in subscriptions
        ),
        "renewal_dates": {
            "required": len(future_items),
            "known": renewal_known,
            "missing": len(future_items) - renewal_known,
        },
    }


def monthly_equivalent(amount: float, cycle: str) -> float:
    return {
        "weekly": amount * 52 / 12,
        "monthly": amount,
        "quarterly": amount / 3,
        "annual": amount / 12,
    }.get(cycle, 0.0)


def alerts() -> list[dict[str, Any]]:
    today = date.today()
    result: list[dict[str, Any]] = []
    for sub in list_subscriptions():
        if sub["status"] == "action_required":
            result.append({"severity": "critical", "type": "payment", "subscription": sub["name"], "message": sub["notes"] or "Payment needs attention"})
        if sub["status"] in {"active", "trial"} and sub["renewal_date"]:
            renewal = date.fromisoformat(sub["renewal_date"])
            days = (renewal - today).days
            if 0 <= days <= 14:
                result.append({"severity": "warning", "type": "renewal", "subscription": sub["name"], "message": f"Renews in {days} day(s) on {renewal.isoformat()}"})
            elif days < 0:
                result.append({"severity": "warning", "type": "stale", "subscription": sub["name"], "message": "Renewal date has passed; verify status"})
        verified = sub["last_verified_at"]
        if verified:
            checked = datetime.fromisoformat(verified).date()
            if checked < today - timedelta(days=45):
                result.append({"severity": "info", "type": "verification", "subscription": sub["name"], "message": "Not verified in 45+ days"})
    return result


def summary() -> dict[str, Any]:
    subs = list_subscriptions()
    live = [s for s in subs if s["status"] in {"active", "action_required", "trial"}]
    totals: dict[str, float] = {}
    for sub in live:
        monthly = monthly_equivalent(float(sub["amount"]), sub["billing_cycle"])
        totals[sub["currency"]] = round(totals.get(sub["currency"], 0) + monthly, 2)
    return {
        "counts": {
            "total": len(subs),
            "live": len(live),
            "active": sum(s["status"] == "active" for s in subs),
            "action_required": sum(s["status"] == "action_required" for s in subs),
        },
        "monthly_totals": totals,
        "alerts": alerts(),
        "coverage": coverage_report(),
        "generated_at": utc_now(),
        "offline": True,
    }


def export_json() -> dict[str, Any]:
    return {"summary": summary(), "subscriptions": list_subscriptions()}


def import_json_file(path: Path) -> int:
    payload = json.loads(path.read_text(encoding="utf-8"))
    items = payload if isinstance(payload, list) else payload.get("subscriptions", [])
    for item in items:
        upsert_subscription(item)
    return len(items)
