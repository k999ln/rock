from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterator


ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DB = ROOT / "data" / "ledger.sqlite3"
VALID_STATUSES = {
    "active",
    "action_required",
    "paused",
    "cancelled",
    "expired",
    "free",
    "trial",
    "usage_based",
}
VALID_CYCLES = {"weekly", "monthly", "quarterly", "annual", "one_time", "usage", "free"}


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def db_path() -> Path:
    configured = os.environ.get("ROCKSTAR_LEDGER_DB")
    return Path(configured).expanduser().resolve() if configured else DEFAULT_DB


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                category TEXT NOT NULL DEFAULT 'Other',
                status TEXT NOT NULL DEFAULT 'active',
                amount REAL NOT NULL DEFAULT 0,
                currency TEXT NOT NULL DEFAULT 'USD',
                billing_cycle TEXT NOT NULL DEFAULT 'monthly',
                renewal_date TEXT,
                payment_method TEXT,
                source TEXT NOT NULL DEFAULT 'manual',
                confidence REAL NOT NULL DEFAULT 1,
                notes TEXT NOT NULL DEFAULT '',
                last_verified_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                occurred_on TEXT NOT NULL,
                merchant TEXT NOT NULL,
                normalized_merchant TEXT NOT NULL,
                amount REAL NOT NULL,
                currency TEXT NOT NULL DEFAULT 'USD',
                source TEXT NOT NULL DEFAULT 'csv',
                external_id TEXT,
                memo TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                UNIQUE(source, external_id)
            );

            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subscription_id INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
                kind TEXT NOT NULL,
                observed_at TEXT NOT NULL,
                summary TEXT NOT NULL,
                source_ref TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
            CREATE INDEX IF NOT EXISTS idx_transactions_merchant ON transactions(normalized_merchant);
            CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(occurred_on);
            """
        )


def _validate_subscription(item: dict[str, Any]) -> dict[str, Any]:
    name = str(item.get("name", "")).strip()
    if not name:
        raise ValueError("name is required")
    status = str(item.get("status", "active"))
    if status not in VALID_STATUSES:
        raise ValueError(f"invalid status: {status}")
    cycle = str(item.get("billing_cycle", "monthly"))
    if cycle not in VALID_CYCLES:
        raise ValueError(f"invalid billing_cycle: {cycle}")
    amount = float(item.get("amount", 0))
    if amount < 0:
        raise ValueError("amount must be zero or positive")
    renewal = item.get("renewal_date") or None
    if renewal:
        date.fromisoformat(str(renewal))
    return {
        "name": name,
        "category": str(item.get("category") or "Other"),
        "status": status,
        "amount": amount,
        "currency": str(item.get("currency") or "USD").upper(),
        "billing_cycle": cycle,
        "renewal_date": renewal,
        "payment_method": str(item.get("payment_method") or ""),
        "source": str(item.get("source") or "manual"),
        "confidence": min(1.0, max(0.0, float(item.get("confidence", 1)))),
        "notes": str(item.get("notes") or ""),
        "last_verified_at": str(item.get("last_verified_at") or utc_now()),
    }


def upsert_subscription(item: dict[str, Any]) -> dict[str, Any]:
    init_db()
    clean = _validate_subscription(item)
    now = utc_now()
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO subscriptions (
                name, category, status, amount, currency, billing_cycle,
                renewal_date, payment_method, source, confidence, notes,
                last_verified_at, created_at, updated_at
            ) VALUES (
                :name, :category, :status, :amount, :currency, :billing_cycle,
                :renewal_date, :payment_method, :source, :confidence, :notes,
                :last_verified_at, :created_at, :updated_at
            )
            ON CONFLICT(name) DO UPDATE SET
                category=excluded.category,
                status=excluded.status,
                amount=excluded.amount,
                currency=excluded.currency,
                billing_cycle=excluded.billing_cycle,
                renewal_date=excluded.renewal_date,
                payment_method=excluded.payment_method,
                source=excluded.source,
                confidence=excluded.confidence,
                notes=excluded.notes,
                last_verified_at=excluded.last_verified_at,
                updated_at=excluded.updated_at
            """,
            clean | {"created_at": now, "updated_at": now},
        )
        row = conn.execute("SELECT * FROM subscriptions WHERE name = ? COLLATE NOCASE", (clean["name"],)).fetchone()
    return dict(row)


def list_subscriptions(status: str | None = None) -> list[dict[str, Any]]:
    init_db()
    query = "SELECT * FROM subscriptions"
    params: tuple[Any, ...] = ()
    if status:
        query += " WHERE status = ?"
        params = (status,)
    query += " ORDER BY CASE status WHEN 'action_required' THEN 0 WHEN 'active' THEN 1 ELSE 2 END, name"
    with connect() as conn:
        return [dict(row) for row in conn.execute(query, params).fetchall()]


def add_evidence(subscription_id: int, kind: str, summary: str, observed_at: str | None = None, source_ref: str = "") -> None:
    init_db()
    with connect() as conn:
        conn.execute(
            "INSERT INTO evidence (subscription_id, kind, observed_at, summary, source_ref, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (subscription_id, kind, observed_at or utc_now(), summary, source_ref, utc_now()),
        )


def list_evidence(subscription_id: int) -> list[dict[str, Any]]:
    init_db()
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM evidence WHERE subscription_id = ? ORDER BY observed_at DESC", (subscription_id,)
        ).fetchall()
    return [dict(row) for row in rows]


def monthly_equivalent(amount: float, cycle: str) -> float:
    return {
        "weekly": amount * 52 / 12,
        "monthly": amount,
        "quarterly": amount / 3,
        "annual": amount / 12,
    }.get(cycle, 0.0)


def alerts() -> list[dict[str, Any]]:
    today = date.today()
    result: list[dict[str, Any]] = []
    for sub in list_subscriptions():
        if sub["status"] == "action_required":
            result.append({"severity": "critical", "type": "payment", "subscription": sub["name"], "message": sub["notes"] or "Payment needs attention"})
        if sub["status"] in {"active", "trial"} and sub["renewal_date"]:
            renewal = date.fromisoformat(sub["renewal_date"])
            days = (renewal - today).days
            if 0 <= days <= 14:
                result.append({"severity": "warning", "type": "renewal", "subscription": sub["name"], "message": f"Renews in {days} day(s) on {renewal.isoformat()}"})
            elif days < 0:
                result.append({"severity": "warning", "type": "stale", "subscription": sub["name"], "message": "Renewal date has passed; verify status"})
        verified = sub["last_verified_at"]
        if verified:
            checked = datetime.fromisoformat(verified).date()
            if checked < today - timedelta(days=45):
                result.append({"severity": "info", "type": "verification", "subscription": sub["name"], "message": "Not verified in 45+ days"})
    return result


def summary() -> dict[str, Any]:
    subs = list_subscriptions()
    live = [s for s in subs if s["status"] in {"active", "action_required", "trial"}]
    totals: dict[str, float] = {}
    for sub in live:
        monthly = monthly_equivalent(float(sub["amount"]), sub["billing_cycle"])
        totals[sub["currency"]] = round(totals.get(sub["currency"], 0) + monthly, 2)
    return {
        "counts": {
            "total": len(subs),
            "live": len(live),
            "active": sum(s["status"] == "active" for s in subs),
            "action_required": sum(s["status"] == "action_required" for s in subs),
        },
        "monthly_totals": totals,
        "alerts": alerts(),
        "generated_at": utc_now(),
        "offline": True,
    }


def export_json() -> dict[str, Any]:
    return {"summary": summary(), "subscriptions": list_subscriptions()}


def import_json_file(path: Path) -> int:
    payload = json.loads(path.read_text(encoding="utf-8"))
    items = payload if isinstance(payload, list) else payload.get("subscriptions", [])
    for item in items:
        upsert_subscription(item)
    return len(items)

