from __future__ import annotations

import argparse
import json
from pathlib import Path

from .db import export_json, import_json_file, init_db, upsert_subscription
from .recurring import import_csv_text


def main() -> None:
    parser = argparse.ArgumentParser(prog="rockstar-ledger")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init")
    sub.add_parser("summary")
    json_import = sub.add_parser("import-json")
    json_import.add_argument("path", type=Path)
    csv_import = sub.add_parser("import-csv")
    csv_import.add_argument("path", type=Path)
    csv_import.add_argument("--source", default="csv")
    csv_import.add_argument("--currency", default="USD")
    upsert = sub.add_parser("upsert")
    upsert.add_argument("name")
    upsert.add_argument("--amount", type=float, default=0)
    upsert.add_argument("--currency", default="USD")
    upsert.add_argument("--cycle", default="monthly")
    upsert.add_argument("--status", default="active")
    upsert.add_argument("--notes", default="")
    args = parser.parse_args()

    if args.command == "init":
        init_db()
        output = {"ok": True}
    elif args.command == "summary":
        output = export_json()
    elif args.command == "import-json":
        output = {"imported": import_json_file(args.path)}
    elif args.command == "import-csv":
        output = import_csv_text(args.path.read_text(encoding="utf-8-sig"), args.source, args.currency)
    else:
        output = upsert_subscription({"name": args.name, "amount": args.amount, "currency": args.currency, "billing_cycle": args.cycle, "status": args.status, "notes": args.notes, "source": "cli"})
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

