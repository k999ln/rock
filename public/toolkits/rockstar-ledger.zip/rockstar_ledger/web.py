from __future__ import annotations

import argparse
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .db import coverage_report, list_subscriptions, summary, upsert_coverage_source, upsert_subscription
from .recurring import detect_recurring, import_csv_text


ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"


class Handler(BaseHTTPRequestHandler):
    server_version = "RockstarLedger/0.1"

    def log_message(self, format: str, *args: object) -> None:
        return

    def _allowed_origin(self) -> str | None:
        raw = self.headers.get("Origin")
        if not raw:
            return None
        parsed = urlparse(raw)
        if parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "localhost", "::1"}:
            return raw
        return None

    def _json(self, payload: object, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        origin = self._allowed_origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/summary":
            return self._json(summary())
        if parsed.path == "/api/subscriptions":
            status = parse_qs(parsed.query).get("status", [None])[0]
            return self._json(list_subscriptions(status))
        if parsed.path == "/api/candidates":
            return self._json(detect_recurring())
        if parsed.path == "/api/coverage":
            return self._json(coverage_report())
        path = WEB / ("index.html" if parsed.path == "/" else parsed.path.lstrip("/"))
        if not path.is_file() or WEB not in path.resolve().parents:
            return self._json({"error": "not found"}, 404)
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        try:
            if self.path == "/api/subscriptions":
                return self._json(upsert_subscription(self._body()), 201)
            if self.path == "/api/import":
                body = self._body()
                return self._json(
                    import_csv_text(
                        body["csv_text"],
                        body.get("source", "web"),
                        body.get("default_currency", "USD"),
                        body.get("source_kind", "credit_card"),
                    ),
                    201,
                )
            if self.path == "/api/coverage":
                return self._json(upsert_coverage_source(self._body()))
            return self._json({"error": "not found"}, 404)
        except Exception as exc:
            return self._json({"error": str(exc)}, 400)

    def do_OPTIONS(self) -> None:
        origin = self._allowed_origin()
        if not origin:
            self.send_response(403)
            self.end_headers()
            return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Vary", "Origin")
        self.end_headers()


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the offline Rockstar Ledger dashboard")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if args.host not in {"127.0.0.1", "localhost", "::1"}:
        raise SystemExit("For privacy, Rockstar Ledger only binds to the local computer.")
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Rockstar Ledger is running at http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
