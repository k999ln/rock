# Rockstar Ledger

サブスク、更新日、支払い失敗、従量課金を一元管理するローカルファーストの顧問ツールです。銀行・カード明細のCSVから定期的な支払い候補も検出します。

- 完全オフライン。外部APIやクラウドDBは不要
- Python標準ライブラリだけで動作
- 個人データは `data/ledger.sqlite3` に保存し、Gitには含めない
- ブラウザのダッシュボードと、AI／RockstarOS向けMCPを同じ台帳に接続
- 通貨を勝手に合算せず、通貨別に月額換算
- 決済失敗、期限切れ、14日以内の更新を優先表示

## すぐ使う

Python 3.10以降が必要です。追加インストールはありません。

```bash
python3 -m rockstar_ledger.cli init
python3 scripts/run_local.py
```

`http://127.0.0.1:8765` を開くとダッシュボードが表示されます。サーバーはローカル端末以外から接続できません。

既存データをJSONから入れる場合：

```bash
python3 -m rockstar_ledger.cli import-json /path/to/subscriptions.json
```

明細CSVを取り込む場合：

```bash
python3 -m rockstar_ledger.cli import-csv /path/to/transactions.csv --source amex --currency JPY
```

CSV列名は `date`, `merchant`, `amount`, `currency`, `id` を推奨します。日本語の代表的な列名にも対応します。取り込みは重複防止され、2回以上の周期的な請求から候補を返します。

## MCP連携

`.mcp.json` はstdio型MCPサーバーを定義しています。クライアントがプラグインのルートを作業ディレクトリにして起動できる場合は、そのまま読み込めます。別の場所から起動する場合は `scripts/mcp_server.py` を絶対パスに置き換えてください。

利用できるツール：

- `ledger_summary` — 月額換算、件数、要対応
- `list_subscriptions` — 契約一覧と状態フィルター
- `upsert_subscription` — 契約の追加・更新
- `import_transactions_csv` — 明細CSVをローカル取り込み
- `detect_recurring_charges` — 定期課金候補の再計算

MCPリソース `subscription://dashboard` から台帳全体をJSONで読めます。

起動確認：

```bash
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}' | python3 scripts/mcp_server.py
```

## RockstarOSへの組み込み

`.rockstaros/plugin.json` にオフライン実行契約を置いてあります。RockstarOS側は次の2つを登録すれば動きます。

1. MCP: `python3 scripts/mcp_server.py`
2. Dashboard: `python3 scripts/run_local.py --port 8765`

台帳を別の場所に置く場合は環境変数 `ROCKSTAR_LEDGER_DB=/安全な場所/ledger.sqlite3` を渡してください。RockstarOS独自のマニフェスト仕様がある場合は `.rockstaros/plugin.json` のキーを対応づければ、実行部分は変更不要です。

## データ形式

JSON取り込みは配列、または `subscriptions` 配列を持つオブジェクトを受け付けます。

```json
{
  "subscriptions": [
    {
      "name": "Example Service",
      "status": "active",
      "amount": 980,
      "currency": "JPY",
      "billing_cycle": "monthly",
      "renewal_date": "2026-10-01",
      "source": "card statement",
      "notes": "Business expense"
    }
  ]
}
```

状態は `active`, `action_required`, `paused`, `cancelled`, `expired`, `free`, `trial`, `usage_based`。周期は `weekly`, `monthly`, `quarterly`, `annual`, `one_time`, `usage`, `free` です。

## 開発・検証

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q rockstar_ledger scripts
```

## 次に伸ばすところ

- Apple Mailのエクスポート（EML/MBOX）取り込み
- Amex、銀行ごとのCSV列マッピング
- 勘定科目・事業按分・消費税区分
- 解約URLと解約証跡の保存
- 月次締めレポート、重複サービス警告、値上げ検出

> これは契約・支出判断を支援するソフトウェアです。税務申告や法的判断の最終責任を代替するものではありません。

