const statusLabels = {
  active: '有効', action_required: '要対応', paused: '一時停止', cancelled: '解約済み',
  expired: '終了', free: '無料', trial: 'トライアル', usage_based: '従量課金'
};
const cycleLabels = { weekly: '毎週', monthly: '毎月', quarterly: '四半期', annual: '毎年', one_time: '単発', usage: '従量', free: '無料' };
const coverageLabels = { unconfirmed: '利用有無を未確認', pending: '確認待ち', imported: '取込済み・要照合', verified: '確認済み', not_used: '利用していない' };

const money = (amount, currency) => new Intl.NumberFormat('ja-JP', { style: 'currency', currency, maximumFractionDigits: currency === 'JPY' ? 0 : 2 }).format(amount);
const escapeHTML = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
const toast = message => { const el = document.querySelector('#toast'); el.textContent = message; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 2200); };

async function getJSON(url, options) {
  const response = await fetch(url, options);
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || '処理に失敗しました');
  return body;
}

async function render() {
  const [summary, subscriptions] = await Promise.all([getJSON('/api/summary'), getJSON('/api/subscriptions')]);
  const totals = Object.entries(summary.monthly_totals).map(([currency, amount]) => money(amount, currency)).join(' + ') || '¥0';
  document.querySelector('#metrics').innerHTML = `
    <article class="metric accent"><span class="label">月額換算</span><strong>${escapeHTML(totals)}</strong></article>
    <article class="metric"><span class="label">契約・候補</span><strong>${summary.counts.total}</strong></article>
    <article class="metric"><span class="label">稼働中</span><strong>${summary.counts.live}</strong></article>
    <article class="metric"><span class="label">網羅確認</span><strong>${summary.coverage.source_counts.resolved} / ${summary.coverage.source_counts.total}</strong></article>`;
  renderCoverage(summary.coverage);
  renderAlerts(summary.alerts);
  renderSubscriptions(subscriptions);
}

function renderCoverage(coverage) {
  const complete = coverage.complete;
  const state = document.querySelector('#coverage-state');
  state.textContent = complete ? '網羅済み' : '未完了';
  state.classList.toggle('complete', complete);
  const missingRenewals = coverage.renewal_dates.missing;
  document.querySelector('#coverage-summary').textContent = complete
    ? `全情報源と今後の更新日を確認済みです。過去の契約 ${coverage.historical_subscriptions}件、取込明細 ${coverage.transactions_imported}件。`
    : `情報源 ${coverage.source_counts.resolved}/${coverage.source_counts.total}確認済み・明細 ${coverage.transactions_imported}件・更新日未登録 ${missingRenewals}件。未確認が残る間は「全網羅」と判定しません。`;
  document.querySelector('#coverage-sources').innerHTML = coverage.sources.map(source => `
    <article class="coverage-source" data-kind="${escapeHTML(source.kind)}">
      <div class="coverage-source-name"><strong>${escapeHTML(source.label)}</strong><span>${source.item_count}件 · ${escapeHTML(source.last_checked_at ? source.last_checked_at.slice(0, 10) : '未確認')}</span></div>
      <select data-field="status" aria-label="${escapeHTML(source.label)}の確認状態">
        ${Object.entries(coverageLabels).map(([value, label]) => `<option value="${value}"${source.status === value ? ' selected' : ''}>${label}</option>`).join('')}
      </select>
      <input data-field="history_start" type="date" value="${escapeHTML(source.history_start || '')}" aria-label="${escapeHTML(source.label)}の確認開始日">
      <span class="coverage-separator">〜</span>
      <input data-field="history_end" type="date" value="${escapeHTML(source.history_end || '')}" aria-label="${escapeHTML(source.label)}の確認終了日">
      <button data-save-coverage>保存</button>
    </article>`).join('');
}

function renderAlerts(items) {
  document.querySelector('#alert-count').textContent = items.length;
  document.querySelector('#alerts').innerHTML = items.length ? items.map(item => `
    <article class="alert ${escapeHTML(item.severity)}"><strong>${escapeHTML(item.subscription)}</strong><span>${escapeHTML(item.message)}</span></article>`).join('') :
    '<article class="alert warning"><strong>対応なし</strong><span>決済失敗や14日以内の更新はありません。</span></article>';
}

function renderSubscriptions(items) {
  const filter = document.querySelector('#filter').value;
  const visible = filter ? items.filter(item => item.status === filter) : items;
  document.querySelector('#subscriptions').innerHTML = visible.map(item => `<tr>
    <td>${escapeHTML(item.name)}<br><small>${escapeHTML(item.category)}</small></td>
    <td><span class="badge ${escapeHTML(item.status)}">${escapeHTML(statusLabels[item.status] || item.status)}</span></td>
    <td>${money(item.amount, item.currency)}</td><td>${escapeHTML(cycleLabels[item.billing_cycle] || item.billing_cycle)}</td>
    <td>${escapeHTML(item.renewal_date || '—')}</td><td>${escapeHTML(item.source)}</td>
  </tr>`).join('');
  document.querySelector('#empty').hidden = visible.length !== 0;
}

document.querySelector('#filter').addEventListener('change', () => getJSON('/api/subscriptions').then(renderSubscriptions));
document.querySelector('#coverage-sources').addEventListener('click', async event => {
  const button = event.target.closest('[data-save-coverage]');
  if (!button) return;
  const row = button.closest('[data-kind]');
  const value = field => row.querySelector(`[data-field="${field}"]`).value || null;
  try {
    await getJSON('/api/coverage', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ kind: row.dataset.kind, status: value('status'), history_start: value('history_start'), history_end: value('history_end') })
    });
    toast('確認状況を保存しました'); await render();
  } catch (error) { toast(error.message); }
});
document.querySelector('#add-button').addEventListener('click', () => document.querySelector('#subscription-dialog').showModal());
document.querySelector('#close-dialog').addEventListener('click', () => document.querySelector('#subscription-dialog').close());
document.querySelector('#subscription-form').addEventListener('submit', async event => {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(event.target));
  values.amount = Number(values.amount || 0);
  if (!values.renewal_date) values.renewal_date = null;
  try {
    await getJSON('/api/subscriptions', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(values) });
    event.target.reset(); document.querySelector('#subscription-dialog').close(); toast('保存しました'); await render();
  } catch (error) { toast(error.message); }
});

document.querySelector('#import-button').addEventListener('click', async () => {
  const csv_text = document.querySelector('#csv').value;
  if (!csv_text.trim()) return toast('CSVを貼り付けてください');
  try {
    const result = await getJSON('/api/import', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ csv_text, source: document.querySelector('#source').value, source_kind: document.querySelector('#source-kind').value }) });
    document.querySelector('#candidates').innerHTML = result.recurring_candidates.length ? result.recurring_candidates.map(item => `<article class="candidate"><strong>${escapeHTML(item.display_name)}</strong><span>${money(item.amount, item.currency)} · ${escapeHTML(cycleLabels[item.billing_cycle])} · 確度 ${Math.round(item.confidence * 100)}%</span></article>`).join('') : '<p class="hint">繰り返し候補はまだありません。2回以上の取引が必要です。</p>';
    toast(`${result.inserted}件を取り込みました`);
  } catch (error) { toast(error.message); }
});

render().catch(error => toast(error.message));
