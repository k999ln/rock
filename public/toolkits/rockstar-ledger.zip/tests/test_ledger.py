from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path


class LedgerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        os.environ["ROCKSTAR_LEDGER_DB"] = str(Path(self.temp.name) / "test.sqlite3")

    def tearDown(self) -> None:
        os.environ.pop("ROCKSTAR_LEDGER_DB", None)
        self.temp.cleanup()

    def test_upsert_and_summary(self) -> None:
        from rockstar_ledger.db import summary, upsert_subscription
        upsert_subscription({"name": "Annual", "amount": 120, "currency": "USD", "billing_cycle": "annual", "status": "active"})
        upsert_subscription({"name": "Monthly", "amount": 10, "currency": "USD", "billing_cycle": "monthly", "status": "action_required", "notes": "Card failed"})
        result = summary()
        self.assertEqual(result["monthly_totals"]["USD"], 20)
        self.assertEqual(result["counts"]["action_required"], 1)
        self.assertEqual(result["alerts"][0]["subscription"], "Monthly")

    def test_recurring_detection_and_deduplication(self) -> None:
        from rockstar_ledger.recurring import import_csv_text
        text = "date,merchant,amount,currency\n2026-06-01,Example Plus,9.99,USD\n2026-07-01,Example Plus,9.99,USD\n2026-08-01,Example Plus,9.99,USD\n"
        first = import_csv_text(text, "test")
        second = import_csv_text(text, "test")
        self.assertEqual(first["inserted"], 3)
        self.assertEqual(second["inserted"], 0)
        self.assertEqual(first["recurring_candidates"][0]["billing_cycle"], "monthly")

    def test_mcp_initialize_and_tools(self) -> None:
        from rockstar_ledger.mcp import handle
        initialized = handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        tools = handle({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        self.assertEqual(initialized["result"]["serverInfo"]["name"], "rockstar-ledger")
        self.assertIn("ledger_summary", [tool["name"] for tool in tools["result"]["tools"]])
        json.dumps(tools)


if __name__ == "__main__":
    unittest.main()

