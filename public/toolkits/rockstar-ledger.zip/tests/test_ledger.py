from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path


class LedgerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        os.environ["ROCKSTAR_LEDGER_DB"] = str(Path(self.temp.name) / "test.sqlite3")

    def tearDown(self) -> None:
        os.environ.pop("ROCKSTAR_LEDGER_DB", None)
        self.temp.cleanup()

    def test_upsert_and_summary(self) -> None:
        from rockstar_ledger.db import summary, upsert_subscription
        upsert_subscription({"name": "Annual", "amount": 120, "currency": "USD", "billing_cycle": "annual", "status": "active"})
        upsert_subscription({"name": "Monthly", "amount": 10, "currency": "USD", "billing_cycle": "monthly", "status": "action_required", "notes": "Card failed"})
        result = summary()
        self.assertEqual(result["monthly_totals"]["USD"], 20)
        self.assertEqual(result["counts"]["action_required"], 1)
        self.assertEqual(result["alerts"][0]["subscription"], "Monthly")

    def test_recurring_detection_and_deduplication(self) -> None:
        from rockstar_ledger.db import coverage_report
        from rockstar_ledger.recurring import import_csv_text
        text = "date,merchant,amount,currency\n2026-06-01,Example Plus,9.99,USD\n2026-07-01,Example Plus,9.99,USD\n2026-08-01,Example Plus,9.99,USD\n"
        first = import_csv_text(text, "test", source_kind="credit_card")
        second = import_csv_text(text, "test", source_kind="credit_card")
        self.assertEqual(first["inserted"], 3)
        self.assertEqual(second["inserted"], 0)
        self.assertEqual(first["recurring_candidates"][0]["billing_cycle"], "monthly")
        coverage = coverage_report()
        card = next(source for source in coverage["sources"] if source["kind"] == "credit_card")
        self.assertEqual(card["status"], "imported")
        self.assertEqual(card["history_start"], "2026-06-01")
        self.assertEqual(card["history_end"], "2026-08-01")
        self.assertEqual(coverage["transactions_imported"], 3)

    def test_coverage_never_claims_complete_with_unresolved_sources_or_renewals(self) -> None:
        from rockstar_ledger.db import coverage_report, upsert_coverage_source, upsert_subscription

        upsert_subscription({"name": "Future Service", "status": "active", "billing_cycle": "monthly"})
        initial = coverage_report()
        self.assertFalse(initial["complete"])
        self.assertEqual(initial["source_counts"]["unresolved"], 6)
        self.assertEqual(initial["renewal_dates"]["missing"], 1)

        for source in initial["sources"]:
            upsert_coverage_source({"kind": source["kind"], "status": "not_used"})
        sources_done = coverage_report()
        self.assertTrue(sources_done["discovery_complete"])
        self.assertFalse(sources_done["future_ready"])
        self.assertFalse(sources_done["complete"])

        upsert_subscription({"name": "Future Service", "status": "active", "billing_cycle": "monthly", "renewal_date": "2026-10-01"})
        self.assertTrue(coverage_report()["complete"])

    def test_mcp_initialize_and_tools(self) -> None:
        from rockstar_ledger.mcp import handle
        initialized = handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        tools = handle({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        self.assertEqual(initialized["result"]["serverInfo"]["name"], "rockstar-ledger")
        self.assertIn("ledger_summary", [tool["name"] for tool in tools["result"]["tools"]])
        self.assertIn("subscription_coverage", [tool["name"] for tool in tools["result"]["tools"]])
        json.dumps(tools)


if __name__ == "__main__":
    unittest.main()
